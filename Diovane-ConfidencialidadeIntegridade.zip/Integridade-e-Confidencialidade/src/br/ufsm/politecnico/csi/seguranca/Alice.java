package br.ufsm.politecnico.csi.seguranca;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.*;
import java.util.Arrays;

/**
 * Created by Evil on 4/13/2017.
 */
public class Alice {
    public static void main(String[] args) throws IOException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, ClassNotFoundException {
        //1. Abrindo Socket
        ServerSocket ss = new ServerSocket(3333);
        System.out.println("1. Socket aberto");

        //2. Gera par chaves
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(1024);
        KeyPair kp = keyGen.generateKeyPair();
        System.out.println("2. Par de chaves gerado.");

        while(true){
            //3. aguarda conexão
            System.out.println("3. Aguardando conexões...");
            Socket s = ss.accept();
            System.out.println("Cliente conectado.");

            //4. Enviando a chave publica
            ObjetoTroca obj = new ObjetoTroca();
            obj.setChavePublica(kp.getPublic());
            ObjectOutputStream out = new ObjectOutputStream(s.getOutputStream());
            out.writeObject(obj);
            out.flush();
            System.out.println("4. Chave publica enviada.");

            //5. Lendo o arquivo do socket
            ObjectInputStream in = new ObjectInputStream(s.getInputStream());
            ObjetoTroca objetoTroca = (ObjetoTroca) in.readObject();
            System.out.println("5. dados recebido.");

            //6. Criar o desencriptador
            Cipher cipherPubicBobHash = Cipher.getInstance("RSA");
            cipherPubicBobHash.init(Cipher.DECRYPT_MODE, objetoTroca.getChavePublica());

            //6. desencriptar hash vindo do bob
            byte[] arquivohashBob= cipherPubicBobHash.doFinal(objetoTroca.getAssinatura());
            System.out.println("6. Descriptografou hash do Bob.");



            //7. cria descriptador com chave privada de alice
            Cipher cipherAlice = Cipher.getInstance("RSA");
            cipherAlice.init(Cipher.DECRYPT_MODE, kp.getPrivate());


            //7. Descriptografar a chave de sessão do Bob com chave privada de Alice
            byte[] c_sessaoBob= cipherAlice.doFinal(objetoTroca.getChaveSessao());
            SecretKeySpec ksBob = new SecretKeySpec(c_sessaoBob,"AES");
            System.out.println("7. Descriptografou chave de sessão.");


            //8. Descriptografar arquivo com chave de sessão de bob
            Cipher cipherBOB = Cipher.getInstance("AES");
            cipherBOB.init(Cipher.DECRYPT_MODE,ksBob);

            byte[] arquivoBob = cipherBOB.doFinal(objetoTroca.getArquivo());
            System.out.println("8. Descriptografou o arquivo.");

            //9. Cria hash do arquivo do BOB
            MessageDigest md = null;
            md = MessageDigest.getInstance("SHA-1");
            byte[] arquivoHasAlice = md.digest(arquivoBob);


            //10. Compara as hash
            if(Arrays.equals(arquivoHasAlice,arquivohashBob))
            {
                //11. Escrever o arquivo
                File saida = new File(objetoTroca.getNomeArquivo());
                OutputStream fout = new FileOutputStream(saida);
                fout.write(objetoTroca.getArquivo());
                fout.close();

                System.out.println("11. Arquivo gravado\n");
            }
            else {
                System.out.println("ERRO! Assinatura Invalida\n");

            }
            s.close();
        }

    }
}
