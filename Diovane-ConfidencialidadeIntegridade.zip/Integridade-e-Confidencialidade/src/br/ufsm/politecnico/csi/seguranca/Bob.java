package br.ufsm.politecnico.csi.seguranca;

import javax.crypto.*;
import javax.swing.*;
import java.io.*;
import java.net.Socket;
import java.security.*;

/**
 * Created by Evil on 4/13/2017.
 */
public class Bob {
    public static void main(String[] args) throws IOException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, ClassNotFoundException {

        //1. Selecionar o arquivo
        JFileChooser chooserArquivo = new JFileChooser();
        int escolha = chooserArquivo.showOpenDialog(new JFrame());
        if (escolha != JFileChooser.APPROVE_OPTION) {
            return;
        }
        System.out.println("1. Selecionou arquivo.");

        //2. Ler o arquivo
        File arquivo = new File(chooserArquivo.getSelectedFile().getAbsolutePath());
        FileInputStream fin = new FileInputStream(arquivo);
        byte[] b_arquivo = new byte[(int) fin.getChannel().size()];
        fin.read(b_arquivo);
        System.out.println("2. Leu o arquivo.");


        //3. Gera par chaves
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(1024);
        KeyPair kp = keyGen.generateKeyPair();
        System.out.println("3. Par de chaves gerado.");


        //4. cria hash do arquivo
        MessageDigest md = null;
        md = MessageDigest.getInstance("SHA-1");
        byte[] b_arquivo_hash = md.digest(b_arquivo);


        //5. Criar o encriptador chave privada
        Cipher cipherRSA_hash = Cipher.getInstance("RSA");
        cipherRSA_hash.init(Cipher.ENCRYPT_MODE, kp.getPrivate());
        System.out.println("5. Criou o encriptador.");

        //6. Criptografar hash e gerar assinatura
        System.out.println("6  Iniciando criptografia arquivo...");
        byte[] assinatura = cipherRSA_hash.doFinal(b_arquivo_hash);
        System.out.println("Criptografou o arquivo.");


        //7. Cria chave de sessão
        KeyGenerator kgen = KeyGenerator.getInstance("AES");
        kgen.init(128);
        SecretKey chaveSessao = kgen.generateKey();
        byte[] chave = chaveSessao.getEncoded();
        System.out.println("7. Criou a Chave de sessão.");


        //8. Criar o encriptador
        Cipher cipherAESarquivo = Cipher.getInstance("AES");
        cipherAESarquivo.init(Cipher.ENCRYPT_MODE, chaveSessao);
        System.out.println("8. Criou o encriptador.");

        //9. Criptografar arquivo com chave de sessã0o
        System.out.println("9. Iniciando criptografia arquivo...");
        byte[] arquivoCriptografado = cipherAESarquivo.doFinal(b_arquivo);
        System.out.println("Criptografou o arquivo com chave de sessão.");


        //10. Conecta com a Alice
        Socket s = new Socket("localhost", 3333);
        System.out.println("10. Conectou a Alice.");

        //11. Receber a chave pública da Alice
        ObjectInputStream in = new ObjectInputStream(s.getInputStream());
        ObjetoTroca obj = (ObjetoTroca) in.readObject();
        System.out.println("11. Recebeu a chave publica.");

        //12. Cria encriptador da chave publica da alice
        Cipher cipherRSAPublicaAlice = Cipher.getInstance("RSA");
        cipherRSAPublicaAlice.init(Cipher.ENCRYPT_MODE, obj.getChavePublica());
        System.out.println("12. Criou o encriptador para chave de sessão.");

        //13. Criptografar chave sessao com chave publica da alice
        System.out.println("13. Iniciando criptografia chave sessão...");
        byte[] chaveSessaoCripto = cipherRSAPublicaAlice.doFinal(chave);
        System.out.println("Criptografou a chave de sessão com chave publica de Alice.");

        //14. Enviar dados
        System.out.println("14. Enviando o arquivos...");
        ObjectOutputStream out = new ObjectOutputStream(s.getOutputStream());
        obj = new ObjetoTroca();

        obj.setChaveSessao(chaveSessaoCripto);//descriptografa com chave privada de Alice
        obj.setArquivo(arquivoCriptografado);//descriptografa com chave de sessao
        obj.setNomeArquivo(chooserArquivo.getSelectedFile().getName());
        obj.setChavePublica(kp.getPublic());//pra descriptografa a assinatura
        obj.setAssinatura(assinatura);//assinatura (hash)

        out.writeObject(obj);
        out.close();
        s.close();
        System.out.println("9. Envio concluído, conexão fechada!");

        System.exit(0);
    }

}
